export CLASSPATH=.:/home/zjhclea/j3d/lib/ext/j3dcore.jar:/home/zjhclea/j3d/lib/ext/j3dutils.jar:/home/zjhclea/j3d/lib/ext/vecmath.jar
export LD_LIBRARY_PATH=/home/zjhclea/j3d/lib/i386
#!cd gui/
java -jar seuGUIUltimate2.0
